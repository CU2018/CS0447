Name: Siyu Zhang
Pitt Username: siz24
Anything that does not work: No

Any extra credit you did: Yes. I did both of them. "in" and "out"

Anything else you think might help us grade your project more easily:
1. I changed the appearances of the "ALU" and the "Return Stack"
2. I implemented the 6 conditional branches in the "ALU" component by doing subtractions,
and send a control signal to the "PC Control" to tell the PC whether it needs to jump.

